package it.uniroma3.dia.db1.jdbc.persistence;

import java.sql.*;

public class DataSource {
	private String dbURI = "jdbc:postgresql://localhost/university";
	private String user = "postgres";
	private String password = "postgres";

	public Connection getConnection() throws Exception {
		Class.forName("org.postgresql.Driver");
		Connection connection = DriverManager.getConnection(dbURI,user, password);
		return connection;
	}
}
